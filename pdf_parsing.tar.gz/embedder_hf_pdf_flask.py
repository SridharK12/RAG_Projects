import base64
import json
from flask import Flask, request
import chromadb
from chromadb.api.types import EmbeddingFunction
from sentence_transformers import SentenceTransformer

# ==========================================================
# 1️⃣ Load Embedding Model Once (Container Startup)
# ==========================================================

hf_model = SentenceTransformer("BAAI/bge-base-en-v1.5")

# ==========================================================
# 2️⃣ Chroma Embedding Wrapper
# ==========================================================

class HFEmbeddingFunction(EmbeddingFunction):
    def __call__(self, texts):
        embeddings = hf_model.encode(
            texts,
            normalize_embeddings=True
        )
        return embeddings.tolist()

# ==========================================================
# 3️⃣ Core Embedding Logic
# ==========================================================

def embed_chunks(chunks):

    # ⚠ /tmp is ephemeral in Cloud Run
    client = chromadb.PersistentClient(path="/tmp/chroma")

    collection = client.get_or_create_collection(
        name="mms_collection_bge",
        embedding_function=HFEmbeddingFunction()
    )

    documents = []
    metadatas = []
    ids = []

    for idx, item in enumerate(chunks):

        documents.append(item["text"])

        metadata = {
            "section_number": item.get("section_number"),
            "section_title": item.get("section_title"),
            "chunk_index": idx
        }

        metadatas.append(metadata)
        ids.append(f"{item.get('document_id','doc')}_{idx}")

    collection.add(
        documents=documents,
        metadatas=metadatas,
        ids=ids
    )

# ==========================================================
# 4️⃣ Flask App (Required for Cloud Run)
# ==========================================================

app = Flask(__name__)

@app.route("/", methods=["POST"])
def pubsub_handler():

    envelope = request.get_json()

    if not envelope or "message" not in envelope:
        return ("Bad Request", 400)

    message = envelope["message"]

    if "data" not in message:
        return ("No Data", 204)

    try:
        decoded_data = base64.b64decode(
            message["data"]
        ).decode("utf-8")

        payload = json.loads(decoded_data)

        chunks = payload["chunks"]

        embed_chunks(chunks)

        # Return 200 ONLY after success
        return ("OK", 200)

    except Exception as e:
        print("Embedding failed:", str(e))
        # Non-200 → Pub/Sub retries
        return ("Error", 500)

# ==========================================================
# 5️⃣ Start Server
# ==========================================================

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
