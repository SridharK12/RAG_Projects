import json
import chromadb
from chromadb.api.types import EmbeddingFunction
import vertexai
from vertexai.language_models import TextEmbeddingModel

# Initialize Vertex once
vertexai.init(
    project="decisive-mapper-483419-t4",
    location="us-central1"
)

# Load embedding model once (GLOBAL)
embedding_model = TextEmbeddingModel.from_pretrained("text-embedding-005")


# Custom Chroma embedding wrapper
class VertexEmbeddingFunction(EmbeddingFunction):
    def __call__(self, texts):
        embeddings = embedding_model.get_embeddings(texts)
        return [e.values for e in embeddings]


def embed_sections_from_file(
    input_json_path: str,
    persist_directory: str,
    collection_name: str = "mms_collection_vertex"
):

    """
    Reads section-wise JSON file and creates embeddings in Chroma.
    """

    # 1️⃣ Load JSON file
    with open(input_json_path, "r", encoding="utf-8") as f:
        chunks = json.load(f)

    print(f"✅ Loaded {len(chunks)} sections from file.")

    print("✅ Embedding model loaded: text-embedding-005")

    # 2️⃣ Initialize Chroma client
    client = chromadb.PersistentClient(path=persist_directory)

    collection = client.get_or_create_collection(
        name=collection_name,
        embedding_function=VertexEmbeddingFunction()
    )

    print(f"✅ Chroma collection '{collection_name}' ready")

    documents = []
    metadatas = []
    ids = []

    for idx, item in enumerate(chunks):

        documents.append(item["text"])

        metadata = {
            "section_number": item.get("section_number"),
            "section_title": item.get("section_title"),
            "start_page": min(item.get("pages", [0])),
            "end_page": max(item.get("pages", [0])),
            "has_tables": len(item.get("tables_structured", [])) > 0,
            "table_count": len(item.get("tables_structured", [])),
            "char_count": item.get("char_count"),
            "checksum": item.get("checksum"),
            "chunk_index": idx,
            "diagram_path": item.get("diagram_path")
        }

        metadatas.append(metadata)
        ids.append(f"section_{item.get('section_number', idx)}")

    # 3️⃣ Batch insert
    collection.add(
        documents=documents,
        metadatas=metadatas,
        ids=ids
    )

    print(f"🚀 Successfully indexed {len(documents)} sections.")

    return collection


if __name__ == "__main__":
    embed_sections_from_file(
        input_json_path="I:\\Sridhar\\rag_learning_level6\\pdf_parsing\\hybrid_section_chunks.json",
        persist_directory="I:\\Sridhar\\rag_learning_level6\\pdf_parsing\\mms_modi"
    )
