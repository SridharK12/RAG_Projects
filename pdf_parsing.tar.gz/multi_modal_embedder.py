"""This code is written to do multi modal embedding  of given document

"""
import json
import os
import chromadb
from chromadb.api.types import EmbeddingFunction
from sentence_transformers import SentenceTransformer
from PIL import Image


# ==========================================================
# 1️⃣ LOAD MODELS
# ==========================================================

# Text Embedding Model (BGE)
text_model = SentenceTransformer("BAAI/bge-base-en-v1.5")

# Image Embedding Model (CLIP)
clip_model = SentenceTransformer("clip-ViT-B-32")


# ==========================================================
# 2️⃣ EMBEDDING FUNCTIONS
# ==========================================================

class TextEmbeddingFunction(EmbeddingFunction):
    def __call__(self, texts):
        embeddings = text_model.encode(
            texts,
            normalize_embeddings=True
        )
        return embeddings.tolist()


class ImageEmbeddingFunction(EmbeddingFunction):
    def __call__(self, image_paths):
        images = []
        for path in image_paths:
            img = Image.open(path).convert("RGB")
            images.append(img)

        embeddings = clip_model.encode(
            images,
            normalize_embeddings=True
        )
        return embeddings.tolist()


# ==========================================================
# 3️⃣ MAIN MULTIMODAL EMBEDDING FUNCTION
# ==========================================================

def embed_multimodal_from_file(
    input_json_path: str,
    persist_directory: str,
    text_collection_name: str = "mms_text_collection",
    image_collection_name: str = "mms_image_collection"
):

    # Load JSON
    with open(input_json_path, "r", encoding="utf-8") as f:
        chunks = json.load(f)

    print(f"✅ Loaded {len(chunks)} sections from file.")

    # Initialize Chroma client
    client = chromadb.PersistentClient(path=persist_directory)

    # Create / Load collections
    text_collection = client.get_or_create_collection(
        name=text_collection_name,
        embedding_function=TextEmbeddingFunction()
    )

    image_collection = client.get_or_create_collection(
        name=image_collection_name,
        embedding_function=ImageEmbeddingFunction()
    )

    print("✅ Text & Image collections ready")

    text_documents = []
    text_metadatas = []
    text_ids = []

    image_paths = []
    image_metadatas = []
    image_ids = []

    for idx, item in enumerate(chunks):

        section_id = f"section_{item.get('section_number', idx)}"

        # -------------------------
        # TEXT EMBEDDING
        # -------------------------
        text_documents.append(item["text"])

        text_metadata = {
            "section_number": item.get("section_number"),
            "section_title": item.get("section_title"),
            "start_page": min(item.get("pages", [0])),
            "end_page": max(item.get("pages", [0])),
            "chunk_index": idx,
            "diagram_path": item.get("diagram_path")
        }

        text_metadatas.append(text_metadata)
        text_ids.append(section_id)

        # -------------------------
        # IMAGE EMBEDDING (IF EXISTS)
        # -------------------------
        diagram_path = item.get("diagram_path")

        if diagram_path and os.path.exists(diagram_path):

            image_paths.append(diagram_path)

            image_metadata = {
                "section_number": item.get("section_number"),
                "section_title": item.get("section_title"),
                "linked_text_id": section_id,
                "diagram_path": diagram_path
            }

            image_metadatas.append(image_metadata)
            image_ids.append(f"image_{section_id}")

    # -------------------------------------------------
    # INSERT TEXT
    # -------------------------------------------------
    if text_documents:
        text_collection.add(
            documents=text_documents,
            metadatas=text_metadatas,
            ids=text_ids
        )
        print(f"🚀 Indexed {len(text_documents)} text sections")

    # -------------------------------------------------
    # INSERT IMAGES
    # -------------------------------------------------
    if image_paths:
        image_collection.add(
            documents=image_paths,  # just storing path reference
            metadatas=image_metadatas,
            ids=image_ids
        )
        print(f"🖼 Indexed {len(image_paths)} diagrams")

    print("✅ Multimodal indexing complete")

    return text_collection, image_collection


# ==========================================================
# 4️⃣ ENTRY POINT
# ==========================================================

if __name__ == "__main__":

    embed_multimodal_from_file(
        input_json_path="I:\\Sridhar\\rag_learning_level6\\pdf_parsing\\hybrid_section_chunks.json",
        persist_directory="I:\\Sridhar\\rag_learning_level6\\pdf_parsing\\mms_modi"
    )
